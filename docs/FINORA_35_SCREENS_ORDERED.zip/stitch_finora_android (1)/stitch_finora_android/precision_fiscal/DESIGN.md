---
name: Precision Fiscal
colors:
  surface: '#f9f9fc'
  surface-dim: '#dadadc'
  surface-bright: '#f9f9fc'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f6'
  surface-container: '#eeeef0'
  surface-container-high: '#e8e8ea'
  surface-container-highest: '#e2e2e5'
  on-surface: '#1a1c1e'
  on-surface-variant: '#3f4945'
  inverse-surface: '#2f3133'
  inverse-on-surface: '#f0f0f3'
  outline: '#707975'
  outline-variant: '#bfc9c4'
  surface-tint: '#29695b'
  primary: '#00342b'
  on-primary: '#ffffff'
  primary-container: '#004d40'
  on-primary-container: '#7ebdac'
  inverse-primary: '#94d3c1'
  secondary: '#046b5e'
  on-secondary: '#ffffff'
  secondary-container: '#9defde'
  on-secondary-container: '#0f6f62'
  tertiary: '#203037'
  on-tertiary: '#ffffff'
  tertiary-container: '#36464e'
  on-tertiary-container: '#a2b3bd'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#afefdd'
  primary-fixed-dim: '#94d3c1'
  on-primary-fixed: '#00201a'
  on-primary-fixed-variant: '#065043'
  secondary-fixed: '#a0f2e1'
  secondary-fixed-dim: '#84d5c5'
  on-secondary-fixed: '#00201b'
  on-secondary-fixed-variant: '#005046'
  tertiary-fixed: '#d4e5ef'
  tertiary-fixed-dim: '#b8c9d3'
  on-tertiary-fixed: '#0d1e25'
  on-tertiary-fixed-variant: '#394951'
  background: '#f9f9fc'
  on-background: '#1a1c1e'
  surface-variant: '#e2e2e5'
typography:
  display-lg:
    fontFamily: Manrope
    fontSize: 44px
    fontWeight: '700'
    lineHeight: 52px
    letterSpacing: -0.02em
  display-md:
    fontFamily: Manrope
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Manrope
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Manrope
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0.01em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.015em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.02em
  numeric-hero:
    fontFamily: JetBrains Mono
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.03em
  numeric-lg:
    fontFamily: JetBrains Mono
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: -0.02em
  numeric-md:
    fontFamily: JetBrains Mono
    fontSize: 15px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: -0.01em
  numeric-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0em
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.03em
  label-sm:
    fontFamily: Inter
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-compact: 0.5rem
  margin: 1rem
  margin-expanded: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system establishes an architectural, high-trust visual language tailored for native Android (Jetpack Compose / Material 3). Built on principles of restrained modernism and mathematical discipline, it avoids gamified tropes, flashy gradients, and playful novelties. Instead, it evokes absolute reliability, quiet confidence, and institutional permanence—akin to premium Swiss financial tools and precision hardware interfaces.

Visual cues lean on clear structural hierarchy, high-density clarity, strict alignment, and tactile feedback. Every visual element serves an analytical purpose: reducing cognitive friction during expense audits, budget reassessments, and rapid receipt input. The interface relies on deliberate content zoning, disciplined white space, purposeful contrast ratios, and strict token-driven states rather than decorative embellishments.

## Colors

The palette utilizes deeply saturated mineral teals paired with clean architectural neutrals and unambiguous semantic status hues. The light baseline offers high-contrast readability under bright ambient light, while the dark theme leverages Material 3 tonal elevation and surface tinting rather than pure blacks.

### Core Swatches & Roles
- **Primary (`#004D40`)**: Anchor brand hue for high-emphasis interactive triggers, key balance states, and primary app bars.
- **Primary Container (`#E0F2F1`)**: Soft background for selected states, active navigation tabs, and prominent summary badges.
- **Secondary (`#00695C`)**: Secondary interactive controls, segment headers, and subtle action indicators.
- **Tertiary / Neutral Variant (`#37474F`)**: Structural framing, subtext headers, and secondary visual dividers.
- **Neutral Surface Baseline (`#F8F9FA`)**: Clean, clinical screen foundation in light mode.
- **Neutral Surface Alt (`#ECEFF1`)**: Tonal grouping background for cards and input regions.
- **Neutral Dark Canvas (`#1A1C1E`)**: Base canvas for dark mode, supporting standard M3 tinted overlays.

### Semantic Status Colors
Financial metrics demand strict, unambiguous feedback. Every status color is strictly paired with an accompanying text label and a dedicated Material Symbols outline icon to ensure accessibility for color-blind users:
- **On Track (`#1E8E3E` / Emerald Green)**: Under-budget spending, healthy savings run rates. Paired with `check_circle`.
- **Near Limit (`#D97706` / Warm Amber)**: Budgets exceeding 80% capacity, pending transaction states. Paired with `warning`.
- **Over Budget (`#D93025` / Crimson Red)**: Exhausted allocations, failed payments, overdraft warnings. Paired with `error`.

### Attention Patterns
Transactions flagged as unconfirmed or requiring categorization apply a dedicated "Needs Review" treatment: a subtle surface tint (`#FFFBEB`), a warm amber border highlight (`#D97706`), and an intentional 1.5dp dashed border stroke paired with the `pending_actions` icon.

## Typography

The type system is engineered to solve a common defect in mobile fintech apps: visual misalignments and jitter in rapid numerical updates. We establish a dual-type architecture:

1. **Structural Prose & Headings (Manrope & Inter)**: Manrope introduces geometric discipline to page anchors, account summaries, and modal titles. Inter provides neutral, highly readable structure for transactional metadata, merchant descriptions, and system instructions.
2. **Financial Data & Numerical Outputs (JetBrains Mono)**: To eliminate layout instability during balance transitions and list parsing, all currency units, transactional sums, percentages, and numeric keypad inputs render via JetBrains Mono with tabular figures enabled. Decimal points and digit columns align strictly along vertical axes across dense statement rows.

## Layout & Spacing

Adhering to native Android ergonomics, all layout, component sizing, and screen paddings strictly adhere to an **8dp baseline grid**, with a **4dp sub-grid** reserved exclusively for micro-alignments (icon-to-label gaps, badge paddings, tag borders).

### Screen & Section Rhythms
- **Mobile Canvas**: Outer boundary margins use `16dp` (`1rem`). Screen padding expands to `24dp` (`1.5rem`) on foldable unfolded states or tablets.
- **Lists and Stacks**: Transaction lists maintain an interior item vertical gap of `8dp` (`space-sm`), enforcing optimal tap target height (minimum `48dp`) while retaining high information density.
- **Card Clustering**: Multi-metric dashboard panels employ a `16dp` (`space-md`) gutter, maintaining discrete visual modules without sprawling layouts.

## Elevation & Depth

Visual hierarchy conforms to the Material 3 tonal elevation model instead of relying on heavy directional drop shadows. Surfaces stack along the Z-axis via subtle value shifts and chromatic surface tints derived from the primary brand teal:

- **Level 0 (Base Canvas)**: Flat `#F8F9FA` (light) / `#1A1C1E` (dark). No shadow, zero tint.
- **Level 1 (Default Content Cards & List Groups)**: Surface `#FFFFFF` (light) / tonal teal composite at 5% opacity over base (dark). 1dp hairline border (`#ECEFF1` in light, `rgba(255,255,255,0.08)` in dark) ensures separation without blur artifacts.
- **Level 2 (Active/Pressed Cards, Bottom Sheets)**: Tinted tonal overlay. Light mode uses a subtle ambient shadow: `0px 2px 8px rgba(0, 77, 64, 0.06)`.
- **Level 3 (Persistent Bottom Navigation Bar)**: Fixed at the base of the viewport with a frosted material backing, 80% opacity, 16dp blur, and a crisp 1dp top divider stroke.
- **Level 4 (Floating Action Button - Add)**: Elevated central primary trigger featuring `0px 4px 12px rgba(0, 77, 64, 0.25)` to assert clear operational priority above scrolling list viewports.

## Shapes

The interface balances modern rounded aesthetics with structural architectural precision. A medium corner radius level (`roundedness: 2`) defines interactive and containment modules:

- **Cards & Data Modules**: Standard `16dp` (`rounded-lg`) corner radii, preserving rectangular structure without visual sharpness.
- **Text Fields & Dropdowns**: `12dp` outer corner radii, providing balanced visual enclosure for numeric and text input.
- **Interactive Buttons & Chips**: Buttons use `12dp` corner rounding for consistent touch affordance. Filter chips, semantic status tags, and currency badges leverage full-pill silhouettes (`999dp`) to clearly contrast with transactional content blocks.
- **Bottom Navigation Dock**: Top corners contoured with `20dp` radii to softly anchor the UI against the gesture bar.

## Components

### Buttons
- **Primary**: Full container `#004D40`, On-Primary `#FFFFFF` (`label-lg`), height `48dp`, shape `12dp`. Supports instantaneous ripple feedback.
- **Secondary**: Outlined 1.5dp border `#004D40`, transparent surface, color `#004D40`.
- **Tonal**: Primary container `#E0F2F1`, text `#004D40`. Used for auxiliary workflow steps like receipt scanning.

### Chips & Semantic Badges
- **Status Badges**: Full-pill `999dp`, height `28dp`, inline horizontal padding `10dp`. Always contains a 16dp Material Symbol outlined icon aligned left, followed by a 4dp gap, and uppercase `label-sm` text.
- **Filter Chips**: Height `32dp`, neutral outline border (`#CFD8DC`), changing to Primary Container (`#E0F2F1`) with Primary text when active.

### Lists & Transaction Rows
- Standard row height `64dp`, comprising an icon container (`40dp` circle with category-coded tint), merchant name (`body-md`, bolded), category descriptor (`body-sm`), and right-aligned amount (`numeric-md`). Positive income streams display a leading `+` in `#1E8E3E`; outgoing expenses render standard font color without negative sign prefix to minimize visual noise.

### Needs Review Transaction Pattern
- Unverified transactions or flagged split items feature an explicit warning state: 1.5dp dashed border stroke (`strokeDasharray: 4 4`) in Warm Amber (`#D97706`), background fill `#FFFBEB`, leading icon `pending_actions` in amber, and an action chip labeled "Categorize".

### Numeric Keypad & Expense Entry
- Full-width custom keypad docked to bottom sheet. Grid arrangement: 3 columns, 4 rows. 
- Touch targets: `64dp` height, zero elevation, subtle border separation. Digits rendered in `JetBrains Mono` (`numeric-hero`). Backspace key anchored bottom right; decimal separator anchored bottom left.

### Bottom Navigation & Add FAB
- **Bottom Navigation**: Persistent `64dp` bar housing 4 core destinations (Home, Budgets, Analytics, Settings). Active items use an indicator pill (`#E0F2F1`) with `#004D40` icons.
- **Elevated Add FAB**: Centered or docked right, `56dp x 56dp` container styled in Deep Teal Primary (`#004D40`), housing a `24dp` white `add` symbol, elevated with Level 4 ambient teal drop shadow.